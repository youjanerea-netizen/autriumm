# Changements — Atrium 2026

- Leçons : 168 au total (88 avant), 19 parcours (9 avant), 263 exercices (103 avant).
- Nouveaux parcours : L'informatique, Terminal, TypeScript, React, Node.js, API et JSON, Algorithmique, Git/livraison/regex, Coder avec l'IA, Projets guidés.
- Python +5 leçons, Java +2 leçons.
- Parcours remis dans l'ordre d'apprentissage ; page d'accueil mise à jour.
- `review.html` régénéré par `build.mjs`.

# Version précédente — Atrium enrichi

- Leçons : 88 au total, 9 parcours.
- Exercices : 103 au total.
- Ajouts : formulaires HTML et accessibilité, DOM, cascade et responsive CSS, structures de données et fonctions JavaScript, localStorage, événements, débogage, fetch et modules, collections et fichiers Python, tests, PDO, sessions et validation PHP, agrégations, relations, transactions SQL, Git, planification et tests de projet.
- Ajout d'un projet de synthèse : mini-portfolio responsive.
- Ajout d'un preset Portfolio dans l'atelier.
- Ajout de `review.html` pour classer les leçons et exporter les retours.
- Nouveau parcours Java : compiler et lancer, types et chaînes, contrôle et tableaux, classes et encapsulation, collections et exceptions.
